package com.virtusa.service;

import java.util.List;

import com.virtusa.model.InterviewerModel;

public interface InterviewerService 
{
	
	public String MarksUpdate(InterviewerModel model);
	public List<InterviewerModel> retriveApplicant();
}
