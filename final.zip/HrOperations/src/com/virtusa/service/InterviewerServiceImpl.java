package com.virtusa.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.dao.InterviewerDAO;
import com.virtusa.entities.Interviewer;
import com.virtusa.factory.FactoryInterviewerDAO;
import com.virtusa.model.InterviewerModel;

public class InterviewerServiceImpl implements InterviewerService {
	private InterviewerDAO interviewerDAO = null;

	public InterviewerServiceImpl(InterviewerDAO interviewerDAO) {
		super();
		this.interviewerDAO = FactoryInterviewerDAO.createInterviewerDao();
	}

	public InterviewerServiceImpl() {
	}

	@Override
	public String MarksUpdate(InterviewerModel model) {

		Interviewer interviewer = new Interviewer();
		interviewer.setApplicantName(model.getApplicant_name());
		interviewer.setResult(model.getResult());
		

		String result = "fail";
		try {
			boolean store = interviewerDAO.storeMarks(interviewer);
			if (store)
				result = "success";
			else {
				System.out.println("data issue ..not updatated ");
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}

		return result;
	}

	@Override
	public List<InterviewerModel> retriveApplicant() {
List<InterviewerModel> interviewerModelList=new ArrayList<>();
try {
	List<Interviewer> applicantList= interviewerDAO.getAllApplicant();
	for(Interviewer interviewer:applicantList)
	{
	InterviewerModel interviewerModel=new InterviewerModel();
	interviewerModel.setApplicant_name(interviewer.getApplicantName());
	interviewerModel.setResult(interviewer.getResult());
	interviewerModelList.add(interviewerModel);
	}
	
} catch (SQLException e) {
	
	e.printStackTrace();
}
		return interviewerModelList;
	}

}
