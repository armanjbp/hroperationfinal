package com.virtusa.view;

import java.util.List;
import java.util.Scanner;

import com.virtusa.controller.InterviewerController;
import com.virtusa.model.InterviewerModel;
import com.virtusa.utilities.UserTypes;

public class InterviewerView {
	Scanner scanner = new Scanner(System.in);
	InterviewerModel interviewerModel = new InterviewerModel();

	public void interviewerView() {
		System.out.println("=======Interviewer View======");
		System.out.println("please enter option");
		System.out.println(" 1.view all apllicant name ");
		System.out.println(" 2.update the result");
		int option = scanner.nextInt();
		if (option == 1) {

			viewApplicantView();

		} else if (option == 2) {
			UpdateResult();
		} else {
			System.out.println("please enter valid option");
		}
	}

	public void UpdateResult() {

		System.out.println("enter name of applicant :");
		String applicantName = scanner.nextLine();
		System.out.print("enter result : ");
		String applicantResult = scanner.nextLine();
		interviewerModel.setApplicant_name(applicantName);
		interviewerModel.setResult(applicantResult);

		InterviewerController interviewerController = new InterviewerController();
		interviewerController.handleRegisterMarks(interviewerModel);

	}

	public void showMarksUpdated(InterviewerModel model) {
		System.out.println("data successfully stored : ");

	}

	public void marksUpdationFail(InterviewerModel model) {
		System.out.println("data not stored : ");

	}
//
//	public void viewmenu() {
//		try (Scanner scanner = new Scanner(System.in);) {
//			System.out.println("view applicant details");
//			int option = scanner.nextInt();
//			switch (option) {
//			case 1:
//				viewApplicantView();
//
//				break;
//
//			default:
//				System.out.println("enter valid input");
//				break;
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

	public void viewApplicantView() {
		try (Scanner scanner = new Scanner(System.in);) {
			System.out.println("1. View applicant Name and Result");

			System.out.print("Enter choice:");
			int option = scanner.nextInt();
			InterviewerController interviewerController = new InterviewerController();
			if (option == 1)
				interviewerController
						.handleRetriveApplicant(UserTypes.INTERVIEWER);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void showApplicant(List<InterviewerModel> models) {
		for (InterviewerModel model : models) {
			System.out.print(model.getApplicant_name()+"  ------   ");
			System.out.println(model.getResult());
		}
	}
}
