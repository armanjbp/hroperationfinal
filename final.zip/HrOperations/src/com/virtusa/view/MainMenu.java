package com.virtusa.view;

import java.util.Scanner;

public class MainMenu {
	public void mainView() {
		InterviewerView interviewerView = new InterviewerView();
		interviewerView.UpdateResult();	}



	
	
}
