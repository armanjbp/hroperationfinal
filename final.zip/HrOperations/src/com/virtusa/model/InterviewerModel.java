package com.virtusa.model;

public class InterviewerModel
{
	
	private String applicant_name;
	private String result;
	private int marks;
	public InterviewerModel() {
	
	}
	public String getApplicant_name() {
		return applicant_name;
	}
	public void setApplicant_name(String applicant_name) {
		this.applicant_name = applicant_name;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	
	@Override
	public String toString() {
		return "InterviewerModel [applicant_name=" + applicant_name + ", result=" + result + ", marks=" + marks + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((applicant_name == null) ? 0 : applicant_name.hashCode());
		result = prime * result + marks;
		result = prime * result + ((this.result == null) ? 0 : this.result.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		InterviewerModel other = (InterviewerModel) obj;
		if (applicant_name == null) {
			if (other.applicant_name != null)
				return false;
		} else if (!applicant_name.equals(other.applicant_name))
			return false;
		if (marks != other.marks)
			return false;
		if (result == null) {
			if (other.result != null)
				return false;
		} else if (!result.equals(other.result))
			return false;
		return true;
	}

	

}
