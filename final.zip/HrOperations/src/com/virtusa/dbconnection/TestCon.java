package com.virtusa.dbconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class TestCon {
	private static DataSource dataSource = new DataSource();

	public static void main(String args[]) {
		System.out.println("coming");
		try {
			Class.forName("com.mysql.jdbc.Driver");

			Connection connection = DriverManager.getConnection(
					dataSource.getUrl(), dataSource.getUsername(),
					dataSource.getPassword());
			PreparedStatement preparedStatement = connection
					.prepareStatement("insert into interviewer values (?,?)");
			preparedStatement.setString(1, "paras");
			preparedStatement.setString(2,"pass");
			
			preparedStatement.execute();
			} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
