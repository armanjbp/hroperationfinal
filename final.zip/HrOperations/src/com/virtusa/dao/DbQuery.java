package com.virtusa.dao;

public class DbQuery
{
	
	//select applicant_name,result from interviewer where applicant_name = 'paras';
//    CREATE TABLE `users` (
//  `userId` int(11) NOT NULL,
//  `userName` varchar(45) NOT NULL,
//  `password` varchar(45) NOT NULL,
//  `email` varchar(45) NOT NULL,
//  `mobile` int(11) NOT NULL,
//  PRIMARY KEY (`userId`)
//) ENGINE=InnoDB DEFAULT CHARSET=utf8
//
//
// saiteja vangawar
//CREATE TABLE `job` (
//`jobId` int(11) NOT NULL,
//`jobTitle` varchar(100) NOT NULL,
//`eligibilityCriteria` varchar(100) NOT NULL,
//`opportunityId` int(11) NOT NULL,
//PRIMARY KEY (`jobId`),
//KEY `deptId_idx` (`opportunityId`),
//CONSTRAINT `opportunityId` FOREIGN KEY (`opportunityId`) REFERENCES `departments` (`deptId`) ON DELETE NO ACTION ON UPDATE NO ACTION
//) ENGINE=InnoDB DEFAULT CHARSET=utf8

//[5:30 PM] saiteja vangawar
//CREATE TABLE `interview` (
//`interviewId` int(11) NOT NULL,
//`venue` varchar(45) NOT NULL,
//`date` date NOT NULL,
//PRIMARY KEY (`interviewId`)
//) ENGINE=InnoDB DEFAULT CHARSET=utf8
//
//[5:30 PM] saiteja vangawar
//CREATE TABLE `employee` (
//`employeeId` int(11) NOT NULL,
//`userId` int(11) NOT NULL,
//`deptId` int(11) NOT NULL,
//`designation` varchar(45) NOT NULL,
//PRIMARY KEY (`employeeId`),
//KEY `userId_idx` (`userId`),
//KEY `deptId_idx` (`deptId`),
//CONSTRAINT `deptId` FOREIGN KEY (`deptId`) REFERENCES `departments` (`deptId`) ON DELETE NO ACTION ON UPDATE NO ACTION,
//CONSTRAINT `userId` FOREIGN KEY (`userId`) REFERENCES `users` (`userId`) ON DELETE NO ACTION ON UPDATE NO ACTION
//) ENGINE=InnoDB DEFAULT CHARSET=utf8
//
//
//[5:29 PM] saiteja vangawar
//CREATE TABLE `departments` (
//`deptId` int(11) NOT NULL,
//`departmentName` varchar(45) NOT NULL,
//PRIMARY KEY (`deptId`)
//) ENGINE=InnoDB DEFAULT CHARSET=utf8
//
//
//[5:29 PM] saiteja vangawar
//CREATE TABLE `applicant` (
//`applicantId` int(11) NOT NULL,
//`applicationStatus` varchar(45) DEFAULT NULL,
//`resultUpdate` varchar(45) DEFAULT NULL,
//PRIMARY KEY (`applicantId`)
//) ENGINE=InnoDB DEFAULT CHARSET=utf8

}
