package com.virtusa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.swing.text.html.HTMLDocument.HTMLReader.PreAction;

import com.virtusa.dbconnection.ConnectionManager;
import com.virtusa.entities.Interviewer;
import com.virtusa.repository.InterviewerRepository;

public class InterviewerDAOImpl implements InterviewerDAO {
	
	
	public boolean storeMarks(Interviewer interviewer) throws SQLException 
	{
		
		Connection connection = ConnectionManager.openConnection();
		PreparedStatement preparedStatement = connection
				.prepareStatement("insert into interviewer values(?,?)");
		preparedStatement.setString(1, interviewer.getApplicantName());
		preparedStatement.setString(2, interviewer.getResult());
		
		int rows = preparedStatement.executeUpdate();
		if (rows >0) {
			return true;
		} else
			return false;

	}

	@Override
	public List<Interviewer> getAllApplicant() throws SQLException {
		Connection connection= ConnectionManager.openConnection();
	Statement statement=	connection.createStatement();
	ResultSet resultSet= statement.executeQuery("select applicant_name,applicant_result from interviewer ");
	List<Interviewer> applicantList =new ArrayList<>();
	
	while(resultSet.next())
	{Interviewer interviewer=new Interviewer();
		interviewer.setApplicantName(resultSet.getString("applicant_name"));
		interviewer.setResult(resultSet.getString("applicant_result"));
		applicantList.add(interviewer);
	}
	
	ConnectionManager.closeConnection();
		
		
		
		return applicantList;
	}
	

}
