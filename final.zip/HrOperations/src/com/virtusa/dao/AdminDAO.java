package com.virtusa.dao;

import com.virtusa.entities.Admin;


public interface AdminDAO {
	public boolean persistJob(Admin admin);

}
