package com.virtusa.ui;

import java.util.Scanner;

import com.virtusa.controller.EmployeeController;
import com.virtusa.helper.RequestType;
import com.virtusa.view.MainView;

public class EmployeesClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MainView mainView=new MainView();
		mainView.mainMenu();
		
	}

}
