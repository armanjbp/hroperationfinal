package com.virtusa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.entities.Departments;
import com.virtusa.entities.Employees;
import com.virtusa.integrate.ConnectionManager;

public class JDBCEmployeesDAOImpl implements EmployeesDAO {

	@Override
	public List<Employees> getAllEmployees() throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection connection=ConnectionManager.openConnection();
		Statement statement=connection.createStatement();
		ResultSet resultSet=
				statement.executeQuery("select applicant_name,result from interviewer");
		
		List<Employees> employeesList=new ArrayList<Employees>();
		while(resultSet.next()) {
			Employees employees=new Employees();
			
			employees.setFirstName(resultSet.getString(1));
			employees.setLastName(resultSet.getString("Result"));
			
			employeesList.add(employees);
		}
		ConnectionManager.closeConnection();
		return employeesList;
	}



}
