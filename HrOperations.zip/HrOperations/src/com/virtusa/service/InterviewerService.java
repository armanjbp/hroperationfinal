package com.virtusa.service;

import com.virtusa.model.InterviewerModel;

public interface InterviewerService 
{
	
	public String MarksUpdate(InterviewerModel model);
}
