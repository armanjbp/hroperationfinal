package com.virtusa.view;

import java.util.Scanner;

import com.virtusa.controller.EmployeeController;
import com.virtusa.helper.RequestType;

public class MainView {

	public void mainMenu() {

		System.out.println("1. View applicant Details");

		try (Scanner scanner = new Scanner(System.in);) {

			System.out.print("Option:");
			int option = scanner.nextInt();

			switch (option) {

			case 1:
				viewEmployeeMenu();
				break;

			}

		} catch (Exception e) {

		}

	}

	public void viewEmployeeMenu() {

		try (Scanner scanner = new Scanner(System.in);) {
			System.out.println("1. View applicant Name and Result");

			

			System.out.print("Enter choice:");
			int option = scanner.nextInt();
			EmployeeController employeeController = new EmployeeController();
			if (option == 1)
				employeeController.handleRetrieveEmployees(RequestType.NAME);



		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
