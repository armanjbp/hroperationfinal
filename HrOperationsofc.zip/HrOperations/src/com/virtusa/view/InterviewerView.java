package com.virtusa.view;

import java.util.List;
import java.util.Scanner;

import com.virtusa.controller.InterviewerController;
import com.virtusa.model.InterviewerModel;
import com.virtusa.utilities.UserTypes;

public class InterviewerView {
	Scanner scanner = new Scanner(System.in);
	InterviewerModel interviewerModel = new InterviewerModel();

	public void interviewerView() {
		System.out.println("=======Interviewer View======");

		UpdateResult();

	}

	public void UpdateResult() {
		System.out.print("enter result : ");
		String applicant_name = scanner.nextLine();

		interviewerModel.setApplicant_name(applicant_name);
		System.out.println(interviewerModel.getApplicant_name()+"marks stored");

		InterviewerController interviewerController = new InterviewerController();
		interviewerController.handleRegisterMarks(interviewerModel);

	}

	public void showMarksUpdated(InterviewerModel model) {
		System.out.println("data successfully stored : ");

	}

	public void marksUpdationFail(InterviewerModel model) {
		System.out.println("data not stored : ");

	}
	public void viewmenu()
	{
		try(Scanner scanner=new Scanner(System.in);)
		{
			System.out.println("view applicant details");
				int option=scanner.nextInt();
				switch (option) {
				case 1:
					viewApplicantView();
					
					break;

				default:System.out.println("enter valid input");
					break;
				}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void viewApplicantView()
	{
		try (Scanner scanner = new Scanner(System.in);) {
			System.out.println("1. View applicant Name and Result");

			

			System.out.print("Enter choice:");
			int option = scanner.nextInt();
			InterviewerController interviewerController = new InterviewerController();
			if (option == 1)
				interviewerController.handleRetriveApplicant(UserTypes.INTERVIEWER);



		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void showApplicant(List<InterviewerModel> models)
	{
		for(InterviewerModel model:models)
		{
			System.out.println(model.getApplicant_name());
		}
	}
}
