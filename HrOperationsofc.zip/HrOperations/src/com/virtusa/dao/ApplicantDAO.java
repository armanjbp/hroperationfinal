package com.virtusa.dao;

import java.util.List;

import com.virtusa.entities.Admin;


public interface ApplicantDAO {
	public List<Admin> viewJobs();


}
