package com.virtusa.userinteface;

import java.util.Scanner;

import com.virtusa.view.InterviewerView;
import com.virtusa.view.MainMenu;

public class UserInterface {

	public static void main(String[] args) 
	{
		
		MainMenu mainMenu = new MainMenu();
	
		try (Scanner scanner = new Scanner(System.in);)
		{
			System.out.println("please enter username");
			String username = scanner.nextLine();
			System.out.println("please enter password");
			
			String password = scanner.nextLine();
			
			
			if (username.contentEquals("admin") && password.contentEquals("admin"))
			{	InterviewerView interviewerView=new InterviewerView();
				
				interviewerView.interviewerView();
				
			
			}
			else
			{	
				System.out.println("enter valid input");
 				mainMenu.mainView();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
